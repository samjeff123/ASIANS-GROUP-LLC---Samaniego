/// <reference types="cypress" />
describe('TC_002 - Users should be able to register  to asians user system', () => {
  beforeEach(() => {
      cy.visit('https://user.asians.group/auth/realms/asians/protocol/openid-connect/auth?client_id=public&redirect_uri=https%3A%2F%2Fconsole.uat.asians.group%2F%23%2Fdomain%2Flist&state=59475741-4afb-4d13-a25e-3d49e9466b4f&response_mode=fragment&response_type=code&scope=openid&nonce=a0902144-b709-44b1-9e7f-716227f98c9d')
  })

  it('TS001 - [User]  Registration - View the Asian User registration pagee', () => {

      //look for register button
      cy.get('#kc-registration > span > a').contains('Register').click()

  })
  it('TS002 - [User]  Login - View the different language available on the page', () => {
      cy.get('#kc-registration > span > a').contains('Register').click()

      //look for 日本語
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('日本語')

      //look for 日本語
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('日本語')

      //look for kr
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('kr')

      //look for English
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('English')

      //look for 中文简体
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('中文简体')

  })

  it('TS003 - [User]  Login - Select the different language available on the page', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()

      //look for 日本語
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('日本語').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('Eメール')

      //look for kr
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('kr').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('이메일')

      //look for English
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('English').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('Email')

      //look for 中文简体
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('中文简体').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('电子邮件')
  })

  it('TS004 - [User]  Registration - Add Valid email', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('#email').type("valid@valid.com")
      cy.get('.pf-c-button').click()
      cy.get('.pf-c-alert__title').contains("Please specify password")
  })

  it('TS005 - To ensure that the user can add a invalid email address', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('#email').type("invalid")
      cy.get('.pf-c-button').click()
      cy.get('.pf-c-alert__title').contains("Please specify password")
      cy.get('.pf-c-alert__title').contains("Invalid email address.")
  })

  it('TS006 - [User]  Registration - Add a Password and Confirm password that is matched', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('#password').type("password")
      cy.get('#password-confirm').type("password")
      cy.get('.pf-c-button').click()
      cy.get('.pf-c-alert__title').contains("Please specify email")
  })

  it('TS007 - [User]  Registration - Add a Password and Confirm password that is matched', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('#password').type("password")
      cy.get('#password-confirm').type("password123")
      cy.get('.pf-c-button').click()
      cy.get('.pf-c-alert__title').contains("Password confirmation doesn't match.")
      cy.get('.pf-c-alert__title').contains("Please specify email")
  })

  it('TS008 -[User]  Registration - Click on the Register button with empty fields', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('.pf-c-button').click()
      cy.get('.pf-c-alert__title').contains("Please specify email")
      cy.get('.pf-c-alert__title').contains("Please specify password")
  })

  it('TS009 -[User]  Registration - Click on the Register button with valid inputs ', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('#email').type("valid@valid.com")
      cy.get('#password').type("valid@valid.com")
      cy.get('#password-confirm').type("valid@valid.com")
      cy.get('.pf-c-button').click()
      cy.wait(6000)
  })

  it('TS010 -[User]  Registration - Click on the Register button with valid inputs ', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('#email').type("valid@valid.com")
      cy.get('#password').type("valid@valid.com")
      cy.get('#password-confirm').type("valid@valid.com")
      cy.get('.pf-c-button').click()
      cy.get('.pf-c-alert__title').contains("Email already exists.")
  })

  it('TS011 -[User]  Registration - Click on the Register button with valid inputs ', () => {

      cy.get('#kc-registration > span > a').contains('Register').click()
      cy.get('span > a').contains("Back to Login").click()
  })

})