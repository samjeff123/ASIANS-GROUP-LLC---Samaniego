/// <reference types="cypress" />
describe('TC_001 - Users should be able to access and login to asians user system', () => {
  beforeEach(() => {
      cy.visit('https://user.asians.group/auth/realms/asians/protocol/openid-connect/auth?client_id=public&redirect_uri=https%3A%2F%2Fconsole.uat.asians.group%2F%23%2Fdomain%2Flist&state=59475741-4afb-4d13-a25e-3d49e9466b4f&response_mode=fragment&response_type=code&scope=openid&nonce=a0902144-b709-44b1-9e7f-716227f98c9d')
  })

  it('TS001 - [User]  Login - View the Asian User login page', () => {
      cy.get('#kc-header-wrapper > span')

      //look for header
      cy.get('#kc-page-title').contains('Sign in to your account')

      //look for drop down
      cy.get('#kc-locale-dropdown')

      //look for login-email
      cy.get('#kc-form-login > :nth-child(1)').contains('Email')

      //look for password
      cy.get('#kc-form-login > :nth-child(2)').contains('Password')

      //look for remember me
      cy.get('.checkbox > label').contains('Remember me')

      //look for forgot password
      cy.get(':nth-child(2) > span > a').contains('Forgot Password?')

      //look for Sign in button
      cy.get('#kc-login').contains('Sign In')

      //look for register button
      cy.get('#kc-registration > span > a').contains('Register')

  })

  it('TS002 - [User]  Login - View the different language available on the page', () => {

      //look for 日本語
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('日本語')

      //look for 日本語
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('日本語')

      //look for kr
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('kr')

      //look for English
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('English')

      //look for 中文简体
      cy.get('#kc-current-locale-link').trigger('mouseover')
      cy.contains('中文简体')

  })

  it('TS003 - [User]  Login - Select the different language available on the page', () => {

      //look for 日本語
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('日本語').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('Eメール')

      //look for kr
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('kr').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('이메일')

      //look for English
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('English').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('Email')

      //look for 中文简体
      cy.get('#kc-locale-dropdown').trigger('mouseover')
          .contains('中文简体').click({
              force: true
          })
      cy.get(':nth-child(1) > .pf-c-form__label').contains('电子邮件')
  })


  it('TS004 - [User]  Login - Add Valid email', () => {
      cy.get('#username').type("jeffemail@gmail.com")
  })

  it('TS005 - [User] Login - Add an invalid email', () => {
      cy.get('#username').type("121212qw")
  })

  it('TS006 - [User]  Login - Add a password', () => {
      cy.get('#password').type("P@ssw0rd")
  })

  it('TS007 - [User]  Login - Tick on the "Remember me" checkbox', () => {
      cy.get('#rememberMe').click()
  })

  it('TS008 - [User]  Login - Untick on the "Remember me" checkbox', () => {
      cy.get('#rememberMe').click().click()
  })

  it('TS009 - [User]  Login - Click on the Forgot Password', () => {
      cy.get(':nth-child(2) > span > a').click()
  })

  it('TS010 - [User]  Login - Click on the Sign in button with empty field', () => {
      cy.get('#kc-login').contains('Sign In')
  })

  it('TS011 - [User]  Login - Click on the Sign in button with incorrect credentials', () => {
      cy.get('#username').type("sample@email.com")
      cy.get('#password').type("wrongpassword")
      cy.get('#kc-login').contains('Sign In')
  })

  it('TS012 - [User]  Login - Click on the Sign in button with unregistered credentials', () => {
      cy.get('#username').type("unregistered@email.com")
      cy.get('#password').type("unregistered")
      cy.get('#kc-login').contains('Sign In')
  })

  it('TS013 - [User]  Login - Click on the Sign in button with unregistered credentials and checked remember me', () => {
      cy.get('#username').type("unregistered@email.com")
      cy.get('#password').type("unregistered")
      cy.get('#rememberMe').click()
      cy.get('#kc-login').contains('Sign In')
  })

  it('TS014 - [User]  Login - Click on the Sign in button with incorrect credentials and checked remember me', () => {
      cy.get('#username').type("incorrect@email.com")
      cy.get('#password').type("incorrect")
      cy.get('#rememberMe').click()
      cy.get('#kc-login').contains('Sign In')
  })

  it('TS015 - [User]  Login - Click on the Sign in button with registered credentials', () => {
      cy.get('#username').type("rv102584@gmail.com")
      cy.get('#password').type("rv102584@gmail.com")
      cy.get('#kc-login').contains('Sign In')
  })

  it('TS016 - [User]  Login - Click on the Sign in button with registered credentials with ticked remember me ', () => {
    cy.get('#username').type("rv102584@gmail.com")
    cy.get('#password').type("rv102584@gmail.com")
    cy.get('#rememberMe').click()
    cy.get('#kc-login').contains('Sign In')
})

it('TS017 - [User]  Login - Click on the "Register" link button', () => {
  cy.get('#kc-registration > span > a').contains('Register')
})

it('TS018 - [User]  Login - Redirect to the homepage upon loging in with the remeber me tick', () => {
  cy.get('#username').type("rv102584@gmail.com")
  cy.get('#password').type("rv102584@gmail.com")
  cy.get('#rememberMe').click()
  cy.get('#kc-login').contains('Sign In')
  cy.visit('https://console.uat.asians.group/#/domain/listhttps://user.asians.group/auth/realms/asians/protocol/openid-connect/auth?client_id=public&redirect_uri=https%3A%2F%2Fconsole.uat.asians.group%2F%23%2Fdomain%2Flist&state=59475741-4afb-4d13-a25e-3d49e9466b4f&response_mode=fragment&response_type=code&scope=openid&nonce=a0902144-b709-44b1-9e7f-716227f98c9d')
  cy.contains('Domains')
})
})